# ui/__init__.py

from .ui_manager import UIManager

__all__ = ["UIManager"]